FB Messenger Bot PHP API
========================

This is a PHP implementation for Facebook Messenger Bot API.

REQUIREMENTS
------------
The minimum requirement is that your Web server supports PHP 5.4.

INSTALLATION
------------

```
composer require "pimax/fb-messenger-php" "dev-master"
```

BASIC USAGE
------------
See this repo - [https://github.com/pimax/fb-messenger-php-example](https://github.com/pimax/fb-messenger-php-example)
